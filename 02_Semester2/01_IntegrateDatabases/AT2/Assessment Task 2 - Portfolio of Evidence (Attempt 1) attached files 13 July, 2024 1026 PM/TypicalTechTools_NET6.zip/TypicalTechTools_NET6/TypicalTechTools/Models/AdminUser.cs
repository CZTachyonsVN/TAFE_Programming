﻿namespace TypicalTechTools.Models
{
    public class AdminUser
    {
        public string Password { get; set; }
    }
}
