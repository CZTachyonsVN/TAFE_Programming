package wordassociation;
public class AssocData
{
    String words;

    public AssocData(String str)
    {
        words = str;
    }
    
    

   
}
