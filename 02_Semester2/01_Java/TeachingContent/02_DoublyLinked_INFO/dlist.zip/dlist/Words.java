/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dlist;

/**
 *
 * @author student
 */
public class Words
{
    String Word1;
    String Word2;            

    public Words()
    {
        Word1 = "First";
        Word2 = "Second";
    }        

    
    public Words(String W1, String W2)
    {
        Word1 = W1;
        Word2 = W2;
    }        

    
}
