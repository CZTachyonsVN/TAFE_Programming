import java.util.ArrayList;
import java.util.Comparator;

public final class Sort
{

    public static ArrayList<Object> QuickSortThree(ArrayList<Object> input)
    {
        ArrayList<Object> output = new ArrayList<>();
        //TODO: Implement QuickSort
        return output;
    }

    public static ArrayList<Object> MergeSort(ArrayList<Object> input)
    {
        ArrayList<Object> output = new ArrayList<>();
        //TODO: Implement MergeSort
        return output;
    }

    public static ArrayList<Object> InsertSort(ArrayList<Object> input)
    {
        ArrayList<Object> output = new ArrayList<>();
        //TODO: Implement InsertSort
        return output;
    }
    
    //private static
}

